export CUDA_LAUNCH_BLOCKING=1
export CUDA_VISIBLE_DEVICES=0

DATA_PATH=/root/data
# DATASET="Beauty"

neg_num_list=(3)
weight_list=(0.1 10.0 100.0)
data_list=("Instruments")
for DATASET in ${data_list[@]}
do
ORG_CKPT_DIR=/root/org_chkpt_TIGER/ckpt/$DATASET/
for neg_num in ${neg_num_list[@]}
do
    for weight in ${weight_list[@]}
    do 
    RESULTS_FILE=/root/results/$DATASET/
    OUTPUT_DIR=/root/ckpt/$DATASET/gfn/${neg_num}/${weight}
    python ./finetune_gfn.py \
    --output_dir $OUTPUT_DIR \
    --dataset $DATASET \
    --data_path $DATA_PATH \
    --gfn_ckpt_path $ORG_CKPT_DIR \
    --per_device_batch_size 256 \
    --learning_rate 5e-4 \
    --epochs 200 \
    --index_file .index.json \
    --temperature 1.0 \
    --gfn_neg_num ${neg_num} \
    --gfn_weight ${weight}  \
    --collab_model_path /root/GFGR/SeqRec/saved/$DATASET/bert4rec/pytorch_model.bin \
    --collab_reward \
    --token_reward \
    --reward_weigted_loss \
    --pretrained
    
    python test.py \
        --gpu_id 0 \
        --ckpt_path $OUTPUT_DIR \
        --dataset $DATASET \
        --data_path $DATA_PATH \
        --results_file $RESULTS_FILE \
        --test_batch_size 480 \
        --num_beams 20 \
        --test_prompt_ids 0 \
        --index_file .new.index.json \
        --gfn_neg_num ${neg_num} \
        --gfn_weight ${weight} 


    done
done
done

